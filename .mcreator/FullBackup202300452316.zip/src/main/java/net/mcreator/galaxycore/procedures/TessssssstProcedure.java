package net.mcreator.galaxycore.procedures;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.ItemStack;

public class TessssssstProcedure {
	public static void execute(ItemStack itemstack) {
		itemstack.enchant(Enchantments.BLOCK_FORTUNE, 10);
		itemstack.enchant(Enchantments.BLOCK_EFFICIENCY, 10);
	}
}
